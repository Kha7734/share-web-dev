'use strict';

import { Express } from 'express';

const app = Express();
app.use('/static/21127734-html', Express.static('static'));
